System.register("chunks:///_virtual/main", ['./PlaneBattle.ts'], function () {
  return {
    setters: [null],
    execute: function () {}
  };
});

System.register("chunks:///_virtual/PlaneBattle.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _createForOfIteratorHelperLoose, _extends, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, Color, Node, Prefab, Sprite, Label, Button, game, UITransform, instantiate, Component;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _createForOfIteratorHelperLoose = module.createForOfIteratorHelperLoose;
      _extends = module.extends;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Color = module.Color;
      Node = module.Node;
      Prefab = module.Prefab;
      Sprite = module.Sprite;
      Label = module.Label;
      Button = module.Button;
      game = module.game;
      UITransform = module.UITransform;
      instantiate = module.instantiate;
      Component = module.Component;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _dec11, _dec12, _dec13, _dec14, _dec15, _dec16, _dec17, _dec18, _dec19, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _descriptor11, _descriptor12, _descriptor13, _descriptor14, _descriptor15, _descriptor16, _descriptor17, _descriptor18, _descriptor19, _descriptor20, _descriptor21, _descriptor22;
      cclegacy._RF.push({}, "c05a0TLo1ZE5boFp93+zi4z", "PlaneBattle", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var TARGET_FRAME_RATE = 60;
      var TRIPLE_SHOT_DURATION = 15;
      var KILLS_PER_POWER_UP = 5;
      var MISSES_ALLOWED_PER_WAVE = 5;
      var POWER_UP_SPEED = 115;
      var SIDE_SHOT_OFFSET = 13;
      var FIRST_BOSS_TIME = 60;
      var BOSS_WARNING_DURATION = 5;
      var FIRST_WAVE_DURATION = FIRST_BOSS_TIME - BOSS_WARNING_DURATION;
      var DIAGONAL_ENEMY_START_TIME = 15;
      var DIAGONAL_ENEMY_INTERVAL = 4;
      var DIAGONAL_ENEMY_DRIFT = 0.35;
      var SECOND_WAVE_ENEMY_SPEED = 175;
      var WAVE_TRANSITION_DURATION = 2;
      var BOSS_HEALTH = 60;
      var BOSS_ENTRY_DURATION = 1;
      var BOSS_PATROL_Y = 164;
      var BOSS_PATROL_WIDTH = 96;
      var BOSS_ATTACK_INTERVAL = 2.8;
      var BOSS_TELEGRAPH_DURATION = 0.7;
      var BOSS_LANE_SPACING = 64;
      var BOSS_SHOT_Y = 133;
      var BOSS_SHOT_SPEED = 280;
      var BOSS_DEFEAT_SCORE = 10;
      var BOSS_DEFEAT_STAGE_MESSAGE = '旗舰已击破 · +10 分';
      var SECOND_WAVE_STAGE_MESSAGE = '第 2 波 · 三发火力 15 秒';
      var SHOOTER_ENEMY_INTERVAL = 8;
      var SHOOTER_ENEMY_INDEX = 6;
      var SHOOTER_FIRE_DEPTH = 60;
      var SHOOTER_WARNING_DURATION = 0.6;
      var SHOOTER_FLASHES_PER_SECOND = 8;
      var ENEMY_SHOT_SPEED = 220;
      var SHOOTER_MARK_COLOR = new Color(255, 232, 96, 255);
      var SHOOTER_ALERT_COLOR = new Color(255, 80, 80, 255);
      var MISS_COUNT_COLOR = new Color(165, 220, 242, 255);
      var MISS_WARNING_COLOR = new Color(255, 198, 139, 255);
      var PlaneBattle = exports('PlaneBattle', (_dec = ccclass('PlaneBattle'), _dec2 = property(Node), _dec3 = property(Node), _dec4 = property(Prefab), _dec5 = property(Prefab), _dec6 = property(Prefab), _dec7 = property(Prefab), _dec8 = property(Prefab), _dec9 = property(Prefab), _dec10 = property(Node), _dec11 = property(Sprite), _dec12 = property(Label), _dec13 = property(Label), _dec14 = property(Label), _dec15 = property(Label), _dec16 = property(Node), _dec17 = property(Label), _dec18 = property(Label), _dec19 = property(Button), _dec(_class = (_class2 = /*#__PURE__*/function (_Component) {
        _inheritsLoose(PlaneBattle, _Component);
        function PlaneBattle() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _initializerDefineProperty(_this, "player", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "flightLayer", _descriptor2, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "bulletPrefab", _descriptor3, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "enemyPrefab", _descriptor4, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "tripleShotPrefab", _descriptor5, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "bossPrefab", _descriptor6, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "bossShotPrefab", _descriptor7, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "bossWarningPrefab", _descriptor8, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "bossHud", _descriptor9, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "bossHealthBar", _descriptor10, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "stageLabel", _descriptor11, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "boostLabel", _descriptor12, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "scoreLabel", _descriptor13, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "missLabel", _descriptor14, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "resultPanel", _descriptor15, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "resultTitle", _descriptor16, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "resultScore", _descriptor17, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "restartButton", _descriptor18, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "shotInterval", _descriptor19, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "enemyInterval", _descriptor20, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "bulletSpeed", _descriptor21, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "enemySpeed", _descriptor22, _assertThisInitialized(_this));
          _this.bullets = [];
          _this.enemies = [];
          _this.powerUps = [];
          _this.bossShots = [];
          _this.enemyShots = [];
          _this.bossWarnings = [];
          _this.phase = {
            kind: 'firstWave',
            remaining: FIRST_WAVE_DURATION
          };
          _this.boostRemaining = 0;
          _this.score = 0;
          _this.killsSinceDrop = 0;
          _this.missedEnemies = 0;
          _this.missLimit = MISSES_ALLOWED_PER_WAVE;
          _this.playing = false;
          _this.timeToShot = 0;
          _this.timeToEnemy = 0;
          _this.enemiesSinceDive = 0;
          _this.secondWaveSpawns = 0;
          _this.dragId = null;
          _this.dragX = 0;
          _this.halfWidth = 0;
          _this.halfHeight = 0;
          _this.playerY = 0;
          _this.playerHalfWidth = 0;
          _this.playerHalfHeight = 0;
          _this.enemyHalfWidth = 0;
          _this.enemyHalfHeight = 0;
          _this.bulletHalfHeight = 0;
          return _this;
        }
        var _proto = PlaneBattle.prototype;
        _proto.onLoad = function onLoad() {
          var required = {
            player: this.player,
            flightLayer: this.flightLayer,
            bulletPrefab: this.bulletPrefab,
            enemyPrefab: this.enemyPrefab,
            tripleShotPrefab: this.tripleShotPrefab,
            bossPrefab: this.bossPrefab,
            bossShotPrefab: this.bossShotPrefab,
            bossWarningPrefab: this.bossWarningPrefab,
            bossHud: this.bossHud,
            bossHealthBar: this.bossHealthBar,
            stageLabel: this.stageLabel,
            boostLabel: this.boostLabel,
            scoreLabel: this.scoreLabel,
            missLabel: this.missLabel,
            resultPanel: this.resultPanel,
            resultTitle: this.resultTitle,
            resultScore: this.resultScore,
            restartButton: this.restartButton
          };
          for (var _i = 0, _arr = Object.keys(required); _i < _arr.length; _i++) {
            var name = _arr[_i];
            if (!required[name]) {
              throw new Error('PlaneBattle is missing its scene reference: ' + name);
            }
          }
          if (!this.enemyPrefab.data.getComponent(Sprite)) {
            throw new Error('PlaneBattle requires a Sprite on the enemy prefab to mark shooting enemies');
          }
          var field = this.getSize(this.node);
          var player = this.getSize(this.player);
          var enemy = this.getSize(this.enemyPrefab.data);
          var bullet = this.getSize(this.bulletPrefab.data);
          this.halfWidth = field.width / 2;
          this.halfHeight = field.height / 2;
          this.playerY = this.player.position.y;
          this.playerHalfWidth = player.width / 2;
          this.playerHalfHeight = player.height / 2;
          this.enemyHalfWidth = enemy.width / 2;
          this.enemyHalfHeight = enemy.height / 2;
          this.bulletHalfHeight = bullet.height / 2;
          var tuning = {
            shotInterval: this.shotInterval,
            enemyInterval: this.enemyInterval,
            bulletSpeed: this.bulletSpeed,
            enemySpeed: this.enemySpeed
          };
          for (var _i2 = 0, _arr2 = Object.keys(tuning); _i2 < _arr2.length; _i2++) {
            var _name = _arr2[_i2];
            var value = tuning[_name];
            if (!Number.isFinite(value) || value <= 0) {
              throw new Error('PlaneBattle expects a positive finite value for ' + _name);
            }
          }
        };
        _proto.onEnable = function onEnable() {
          this.node.on(Node.EventType.TOUCH_START, this.beginDrag, this);
          this.node.on(Node.EventType.TOUCH_MOVE, this.moveDrag, this);
          this.node.on(Node.EventType.TOUCH_END, this.endDrag, this);
          this.node.on(Node.EventType.TOUCH_CANCEL, this.endDrag, this);
          this.restartButton.node.on(Button.EventType.CLICK, this.startRound, this);
        };
        _proto.onDisable = function onDisable() {
          this.node.off(Node.EventType.TOUCH_START, this.beginDrag, this);
          this.node.off(Node.EventType.TOUCH_MOVE, this.moveDrag, this);
          this.node.off(Node.EventType.TOUCH_END, this.endDrag, this);
          this.node.off(Node.EventType.TOUCH_CANCEL, this.endDrag, this);
          this.restartButton.node.off(Button.EventType.CLICK, this.startRound, this);
          this.dragId = null;
        };
        _proto.start = function start() {
          game.frameRate = TARGET_FRAME_RATE;
          this.startRound();
        };
        _proto.update = function update(dt) {
          var _this2 = this;
          if (!this.playing) {
            return;
          }
          var phase = this.phase;
          var enemySpeed = phase.kind === 'secondWave' ? SECOND_WAVE_ENEMY_SPEED : this.enemySpeed;
          this.moveObjects(this.bullets, this.bulletSpeed * dt);
          this.moveObjects(this.enemies, -enemySpeed * dt);
          this.moveObjects(this.powerUps, -POWER_UP_SPEED * dt);
          this.moveObjects(this.bossShots, -BOSS_SHOT_SPEED * dt);
          this.moveObjects(this.enemyShots, -ENEMY_SHOT_SPEED * dt);
          if (phase.kind === 'boss') {
            this.moveBoss(phase, dt);
          }

          // Resolve player damage before awarding any points from this update.
          var player = this.player.position;
          var hitsPlayer = function hitsPlayer(object) {
            return _this2.hits(object, player.x, player.y, player.y, _this2.playerHalfWidth, _this2.playerHalfHeight);
          };
          if (this.enemies.some(hitsPlayer) || this.bossShots.some(hitsPlayer) || this.enemyShots.some(hitsPlayer)) {
            this.endRound('本局结束');
            return;
          }
          this.updatePowerUps(dt);
          this.updateBulletHits();
          this.updateMisses(player.y - this.playerHalfHeight);
          this.removeOffscreen(this.enemies);
          if (!this.playing) {
            return;
          }
          this.removeOffscreen(this.bossShots);
          this.removeOffscreen(this.enemyShots);
          this.updateEnemyFire(dt);
          this.updatePlayerFire(dt);

          // The victory frame belongs to the Boss fight, not the next wave's countdown.
          if (this.phase === phase) {
            this.updatePhase(phase, dt);
          }
        };
        _proto.updatePowerUps = function updatePowerUps(dt) {
          var player = this.player.position;
          if (this.phase.kind !== 'intermission') {
            this.boostRemaining = Math.max(0, this.boostRemaining - dt);
          }
          for (var index = this.powerUps.length - 1; index >= 0; index--) {
            var powerUp = this.powerUps[index];
            if (this.hits(powerUp, player.x, player.y, player.y, this.playerHalfWidth, this.playerHalfHeight)) {
              this.boostRemaining = TRIPLE_SHOT_DURATION;
              this.removeObject(this.powerUps, index);
            } else if (powerUp.node.position.y + powerUp.halfHeight < -this.halfHeight) {
              this.removeObject(this.powerUps, index);
            }
          }
          this.updateBoostLabel();
        };
        _proto.updateBulletHits = function updateBulletHits() {
          var _this3 = this;
          var _loop = function _loop() {
            var bullet = _this3.bullets[bulletIndex];
            var position = bullet.node.position;
            var enemyIndex = _this3.enemies.findIndex(function (enemy) {
              return _this3.hits(enemy, position.x, bullet.previousY, position.y, bullet.halfWidth, bullet.halfHeight);
            });
            if (enemyIndex !== -1) {
              var enemyPosition = _this3.enemies[enemyIndex].node.position;
              _this3.addScore(1);
              if (++_this3.killsSinceDrop % KILLS_PER_POWER_UP === 0) {
                _this3.powerUps.push(_this3.spawn(_this3.tripleShotPrefab, enemyPosition.x, enemyPosition.y));
              }
              _this3.removeObject(_this3.enemies, enemyIndex);
              _this3.removeObject(_this3.bullets, bulletIndex);
            } else if (_this3.phase.kind === 'boss' && _this3.hits(_this3.phase.ship, position.x, bullet.previousY, position.y, bullet.halfWidth, bullet.halfHeight)) {
              var boss = _this3.phase;
              _this3.removeObject(_this3.bullets, bulletIndex);
              _this3.bossHealthBar.fillRange = --boss.health / BOSS_HEALTH;
              if (boss.health === 0) {
                _this3.defeatBoss(boss);
              }
            } else if (position.y - bullet.halfHeight > _this3.halfHeight) {
              _this3.removeObject(_this3.bullets, bulletIndex);
            }
          };
          for (var bulletIndex = this.bullets.length - 1; bulletIndex >= 0; bulletIndex--) {
            _loop();
          }
        };
        _proto.updateMisses = function updateMisses(playerBottom) {
          var previousCount = this.missedEnemies;
          for (var _iterator = _createForOfIteratorHelperLoose(this.enemies), _step; !(_step = _iterator()).done;) {
            var enemy = _step.value;
            if (enemy.hasPassedPlayer || enemy.node.position.y + enemy.passHalfHeight >= playerBottom) {
              continue;
            }
            enemy.hasPassedPlayer = true;
            if (++this.missedEnemies > this.missLimit) {
              break;
            }
          }
          if (this.missedEnemies !== previousCount) {
            this.updateMissLabel();
            if (this.missedEnemies > this.missLimit) {
              this.endRound('漏防超限');
            }
          }
        };
        _proto.resetMisses = function resetMisses(wave) {
          this.missedEnemies = 0;
          this.missLimit = wave * MISSES_ALLOWED_PER_WAVE;
          this.updateMissLabel();
        };
        _proto.updateMissLabel = function updateMissLabel() {
          var atLimit = this.missedEnemies === this.missLimit;
          this.missLabel.string = '漏防 ' + this.missedEnemies + '/' + this.missLimit + (atLimit ? ' · 再漏即败' : '');
          this.missLabel.color = this.missedEnemies >= this.missLimit ? MISS_WARNING_COLOR : MISS_COUNT_COLOR;
        };
        _proto.removeOffscreen = function removeOffscreen(objects) {
          for (var index = objects.length - 1; index >= 0; index--) {
            var object = objects[index];
            if (object.node.position.y + object.halfHeight < -this.halfHeight) {
              this.removeObject(objects, index);
            }
          }
        };
        _proto.updatePlayerFire = function updatePlayerFire(dt) {
          this.timeToShot -= dt;
          if (this.timeToShot <= 0) {
            this.timeToShot = this.shotInterval;
            var y = this.playerY + this.playerHalfHeight + this.bulletHalfHeight;
            var x = this.player.position.x;
            this.bullets.push(this.spawn(this.bulletPrefab, x, y));
            if (this.boostRemaining > 0) {
              this.bullets.push(this.spawn(this.bulletPrefab, x - SIDE_SHOT_OFFSET, y));
              this.bullets.push(this.spawn(this.bulletPrefab, x + SIDE_SHOT_OFFSET, y));
            }
          }
        };
        _proto.updatePhase = function updatePhase(phase, dt) {
          switch (phase.kind) {
            case 'firstWave':
              phase.remaining -= dt;
              if (phase.remaining <= 0) {
                this.phase = {
                  kind: 'warning',
                  remaining: BOSS_WARNING_DURATION + phase.remaining
                };
                this.showStage('敌方旗舰即将出现');
              } else {
                this.updateEnemySpawn(dt, phase.remaining <= FIRST_WAVE_DURATION - DIAGONAL_ENEMY_START_TIME, false);
              }
              break;
            case 'warning':
              phase.remaining -= dt;
              if (phase.remaining <= 0) {
                this.startBoss();
              }
              break;
            case 'boss':
              this.updateBossAttack(phase, dt);
              break;
            case 'intermission':
              phase.remaining -= dt;
              if (phase.remaining <= 0) {
                this.stageLabel.node.active = false;
                // The boss reward lands with the wave it was earned for, keeping the full duration playable.
                this.boostRemaining = TRIPLE_SHOT_DURATION;
                this.updateBoostLabel();
                this.timeToEnemy = this.enemyInterval;
                this.enemiesSinceDive = 0;
                this.secondWaveSpawns = 0;
                this.phase = {
                  kind: 'secondWave'
                };
                this.resetMisses(2);
              } else {
                this.showStage(phase.remaining <= WAVE_TRANSITION_DURATION / 2 ? SECOND_WAVE_STAGE_MESSAGE : BOSS_DEFEAT_STAGE_MESSAGE);
              }
              break;
            case 'secondWave':
              this.updateEnemySpawn(dt, true, true);
              break;
          }
        };
        _proto.updateEnemySpawn = function updateEnemySpawn(dt, allowDiagonal, allowShooter) {
          this.timeToEnemy -= dt;
          if (this.timeToEnemy > 0) {
            return;
          }
          this.timeToEnemy = this.enemyInterval;
          var y = this.halfHeight + this.enemyHalfHeight;
          var side = Math.random() * 2 - 1;
          // The 6th of every 8 second-wave enemies fires a shot; it never lands on a dive slot.
          var shooter = allowShooter && ++this.secondWaveSpawns % SHOOTER_ENEMY_INTERVAL === SHOOTER_ENEMY_INDEX;
          var dive = allowDiagonal ? ++this.enemiesSinceDive : 0;
          if (!shooter && dive === DIAGONAL_ENEMY_INTERVAL) {
            this.enemiesSinceDive = 0;
            var drift = side < 0 ? DIAGONAL_ENEMY_DRIFT : -DIAGONAL_ENEMY_DRIFT;
            // Mirrored dives start on one side and cross the middle of the playfield.
            this.enemies.push(this.spawnEnemy(-drift * y, y, drift));
          } else {
            var x = side * (this.halfWidth - this.enemyHalfWidth);
            var enemy = this.spawnEnemy(x, y);
            if (shooter) {
              this.markShooter(enemy);
            }
            this.enemies.push(enemy);
          }
        };
        _proto.spawnEnemy = function spawnEnemy(x, y, horizontalDrift) {
          if (horizontalDrift === void 0) {
            horizontalDrift = 0;
          }
          var enemy = this.spawn(this.enemyPrefab, x, y, horizontalDrift);
          var angle = Math.atan(horizontalDrift);
          enemy.node.angle = angle * 180 / Math.PI;
          return _extends({}, enemy, {
            shooter: null,
            hasPassedPlayer: false,
            passHalfHeight: Math.cos(angle) * enemy.halfHeight + Math.abs(Math.sin(angle)) * enemy.halfWidth
          });
        };
        _proto.markShooter = function markShooter(enemy) {
          var sprite = enemy.node.getComponent(Sprite);
          sprite.color = SHOOTER_MARK_COLOR;
          enemy.shooter = {
            kind: 'armed',
            timeToFire: 0,
            sprite: sprite
          };
        };
        _proto.updateEnemyFire = function updateEnemyFire(dt) {
          for (var _iterator2 = _createForOfIteratorHelperLoose(this.enemies), _step2; !(_step2 = _iterator2()).done;) {
            var enemy = _step2.value;
            var shooter = enemy.shooter;
            if (!shooter) {
              continue;
            }
            if (shooter.kind === 'armed') {
              if (enemy.node.position.y <= this.halfHeight - SHOOTER_FIRE_DEPTH) {
                shooter.kind = 'warning';
                shooter.timeToFire = SHOOTER_WARNING_DURATION;
              }
              continue;
            }
            shooter.timeToFire -= dt;
            var elapsed = SHOOTER_WARNING_DURATION - shooter.timeToFire;
            shooter.sprite.color = Math.floor(elapsed * SHOOTER_FLASHES_PER_SECOND) % 2 === 0 ? SHOOTER_ALERT_COLOR : SHOOTER_MARK_COLOR;
            if (shooter.timeToFire <= 0) {
              var position = enemy.node.position;
              this.enemyShots.push(this.spawn(this.bossShotPrefab, position.x, position.y));
              shooter.sprite.color = SHOOTER_MARK_COLOR;
              enemy.shooter = null;
            }
          }
        };
        _proto.startBoss = function startBoss() {
          var size = this.getSize(this.bossPrefab.data);
          var ship = this.spawn(this.bossPrefab, 0, this.halfHeight + size.height / 2);
          this.phase = {
            kind: 'boss',
            ship: ship,
            health: BOSS_HEALTH,
            elapsed: 0,
            timeToAttack: BOSS_ATTACK_INTERVAL - BOSS_TELEGRAPH_DURATION
          };
          this.stageLabel.node.active = false;
          this.bossHealthBar.fillRange = 1;
          this.bossHud.active = true;
        };
        _proto.moveBoss = function moveBoss(boss, dt) {
          boss.elapsed += dt;
          var ship = boss.ship;
          var entry = Math.min(1, boss.elapsed / BOSS_ENTRY_DURATION);
          var top = this.halfHeight + ship.halfHeight;
          var y = top + (BOSS_PATROL_Y - top) * entry;
          var patrolTime = Math.max(0, boss.elapsed - BOSS_ENTRY_DURATION);
          var x = Math.sin(patrolTime * 0.9) * BOSS_PATROL_WIDTH;
          this.moveObject(ship, x, y);
        };
        _proto.updateBossAttack = function updateBossAttack(boss, dt) {
          boss.timeToAttack -= dt;
          if (boss.timeToAttack > 0) {
            return;
          }
          if (this.bossWarnings.length > 0) {
            for (var _iterator3 = _createForOfIteratorHelperLoose(this.bossWarnings), _step3; !(_step3 = _iterator3()).done;) {
              var warning = _step3.value;
              this.bossShots.push(this.spawn(this.bossShotPrefab, warning.node.position.x, BOSS_SHOT_Y));
            }
            this.clearObjects(this.bossWarnings);
            boss.timeToAttack = BOSS_ATTACK_INTERVAL - BOSS_TELEGRAPH_DURATION;
            return;
          }
          var playerX = this.player.position.x;
          var triple = boss.health <= BOSS_HEALTH / 2;
          // At the edges, shift the entire spread so all three lanes stay playable.
          var centerLimit = this.halfWidth - this.playerHalfWidth - BOSS_LANE_SPACING;
          var center = Math.max(-centerLimit, Math.min(centerLimit, playerX));
          var lanes = triple ? [center - BOSS_LANE_SPACING, center, center + BOSS_LANE_SPACING] : [playerX];
          var warningHeight = BOSS_SHOT_Y + this.halfHeight;
          for (var _i3 = 0, _lanes = lanes; _i3 < _lanes.length; _i3++) {
            var x = _lanes[_i3];
            var _warning = this.spawn(this.bossWarningPrefab, x, BOSS_SHOT_Y - warningHeight / 2);
            this.getSize(_warning.node).height = warningHeight;
            this.bossWarnings.push(_warning);
          }
          boss.timeToAttack = BOSS_TELEGRAPH_DURATION;
        };
        _proto.defeatBoss = function defeatBoss(boss) {
          this.destroyObject(boss.ship);
          this.clearObjects(this.bossShots);
          this.clearObjects(this.bossWarnings);
          this.bossHud.active = false;
          this.addScore(BOSS_DEFEAT_SCORE);
          this.phase = {
            kind: 'intermission',
            remaining: WAVE_TRANSITION_DURATION
          };
          this.showStage(BOSS_DEFEAT_STAGE_MESSAGE);
        };
        _proto.showStage = function showStage(message) {
          if (this.stageLabel.string !== message) {
            this.stageLabel.string = message;
          }
          this.stageLabel.node.active = true;
        };
        _proto.addScore = function addScore(points) {
          this.score += points;
          this.scoreLabel.string = String(this.score);
        };
        _proto.endRound = function endRound(title) {
          this.playing = false;
          this.dragId = null;
          this.boostRemaining = 0;
          this.updateBoostLabel();
          this.clearObjects(this.bossWarnings);
          this.bossHud.active = false;
          this.stageLabel.node.active = false;
          this.resultTitle.string = title;
          this.resultScore.string = '本局得分  ' + this.score;
          this.resultPanel.active = true;
        };
        _proto.startRound = function startRound() {
          for (var _i4 = 0, _arr3 = [this.bullets, this.enemies, this.powerUps, this.bossShots, this.enemyShots, this.bossWarnings]; _i4 < _arr3.length; _i4++) {
            var objects = _arr3[_i4];
            this.clearObjects(objects);
          }
          if (this.phase.kind === 'boss') {
            this.destroyObject(this.phase.ship);
          }
          this.phase = {
            kind: 'firstWave',
            remaining: FIRST_WAVE_DURATION
          };
          this.bossHud.active = false;
          this.stageLabel.node.active = false;
          this.boostRemaining = 0;
          this.updateBoostLabel();
          this.player.setPosition(0, this.playerY);
          this.dragId = null;
          this.score = 0;
          this.killsSinceDrop = 0;
          this.scoreLabel.string = '0';
          this.resetMisses(1);
          this.resultPanel.active = false;
          this.timeToShot = this.shotInterval;
          this.timeToEnemy = this.enemyInterval;
          this.enemiesSinceDive = 0;
          this.secondWaveSpawns = 0;
          this.playing = true;
        };
        _proto.updateBoostLabel = function updateBoostLabel() {
          var text = this.boostRemaining > 0 ? '三发火力  ' + Math.ceil(this.boostRemaining) + 's' : '';
          if (this.boostLabel.string !== text) {
            this.boostLabel.string = text;
          }
          this.boostLabel.node.active = this.boostRemaining > 0;
        };
        _proto.beginDrag = function beginDrag(event) {
          if (this.playing && this.dragId === null) {
            this.dragId = event.getID();
            this.dragX = event.getUILocation().x;
          }
        };
        _proto.moveDrag = function moveDrag(event) {
          if (this.dragId === null || event.getID() !== this.dragId) {
            return;
          }
          var x = event.getUILocation().x;
          var limit = this.halfWidth - this.playerHalfWidth;
          var target = this.player.position.x + x - this.dragX;
          this.player.setPosition(Math.max(-limit, Math.min(limit, target)), this.playerY);
          this.dragX = x;
        };
        _proto.endDrag = function endDrag(event) {
          if (event.getID() === this.dragId) {
            this.dragId = null;
          }
        };
        _proto.getSize = function getSize(node) {
          var transform = node.getComponent(UITransform);
          if (!transform || transform.width <= 0 || transform.height <= 0) {
            throw new Error('PlaneBattle requires a positive UI size on ' + node.name);
          }
          return transform;
        };
        _proto.spawn = function spawn(prefab, x, y, horizontalDrift) {
          if (horizontalDrift === void 0) {
            horizontalDrift = 0;
          }
          var node = instantiate(prefab);
          var size = this.getSize(node);
          node.setPosition(x, y);
          this.flightLayer.addChild(node);
          return {
            node: node,
            previousX: x,
            previousY: y,
            horizontalDrift: horizontalDrift,
            halfWidth: size.width / 2,
            halfHeight: size.height / 2
          };
        };
        _proto.moveObjects = function moveObjects(objects, dy) {
          for (var _iterator4 = _createForOfIteratorHelperLoose(objects), _step4; !(_step4 = _iterator4()).done;) {
            var object = _step4.value;
            var position = object.node.position;
            this.moveObject(object, position.x + Math.abs(dy) * object.horizontalDrift, position.y + dy);
          }
        };
        _proto.moveObject = function moveObject(object, x, y) {
          var position = object.node.position;
          object.previousX = position.x;
          object.previousY = position.y;
          object.node.setPosition(x, y);
        };
        _proto.hits = function hits(object, x, startY, y, halfWidth, halfHeight) {
          var position = object.node.position;
          var startGapY = startY - object.previousY;
          var endGapY = y - position.y;
          var reachY = halfHeight + object.halfHeight;
          if (Math.min(startGapY, endGapY) > reachY || Math.max(startGapY, endGapY) < -reachY) {
            return false;
          }
          var startGapX = x - object.previousX;
          var deltaX = object.previousX - position.x;
          var reachX = halfWidth + object.halfWidth;
          if (deltaX === 0) {
            return Math.abs(startGapX) <= reachX;
          }

          // Only test horizontal overlap during the part of the frame with vertical overlap.
          var deltaY = endGapY - startGapY;
          var enter = 0;
          var exit = 1;
          if (deltaY !== 0) {
            var firstEdge = (-reachY - startGapY) / deltaY;
            var secondEdge = (reachY - startGapY) / deltaY;
            enter = Math.max(0, Math.min(firstEdge, secondEdge));
            exit = Math.min(1, Math.max(firstEdge, secondEdge));
          }
          var entryGapX = startGapX + enter * deltaX;
          var exitGapX = startGapX + exit * deltaX;
          return Math.min(entryGapX, exitGapX) <= reachX && Math.max(entryGapX, exitGapX) >= -reachX;
        };
        _proto.removeObject = function removeObject(objects, index) {
          var _objects$splice = objects.splice(index, 1),
            object = _objects$splice[0];
          this.destroyObject(object);
        };
        _proto.clearObjects = function clearObjects(objects) {
          for (var _iterator5 = _createForOfIteratorHelperLoose(objects), _step5; !(_step5 = _iterator5()).done;) {
            var object = _step5.value;
            this.destroyObject(object);
          }
          objects.length = 0;
        };
        _proto.destroyObject = function destroyObject(object) {
          object.node.removeFromParent();
          object.node.destroy();
        };
        return PlaneBattle;
      }(Component), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "player", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "flightLayer", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "bulletPrefab", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "enemyPrefab", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "tripleShotPrefab", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "bossPrefab", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "bossShotPrefab", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "bossWarningPrefab", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "bossHud", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor10 = _applyDecoratedDescriptor(_class2.prototype, "bossHealthBar", [_dec11], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor11 = _applyDecoratedDescriptor(_class2.prototype, "stageLabel", [_dec12], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor12 = _applyDecoratedDescriptor(_class2.prototype, "boostLabel", [_dec13], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor13 = _applyDecoratedDescriptor(_class2.prototype, "scoreLabel", [_dec14], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor14 = _applyDecoratedDescriptor(_class2.prototype, "missLabel", [_dec15], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor15 = _applyDecoratedDescriptor(_class2.prototype, "resultPanel", [_dec16], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor16 = _applyDecoratedDescriptor(_class2.prototype, "resultTitle", [_dec17], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor17 = _applyDecoratedDescriptor(_class2.prototype, "resultScore", [_dec18], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor18 = _applyDecoratedDescriptor(_class2.prototype, "restartButton", [_dec19], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor19 = _applyDecoratedDescriptor(_class2.prototype, "shotInterval", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 0.24;
        }
      }), _descriptor20 = _applyDecoratedDescriptor(_class2.prototype, "enemyInterval", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 0.78;
        }
      }), _descriptor21 = _applyDecoratedDescriptor(_class2.prototype, "bulletSpeed", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 540;
        }
      }), _descriptor22 = _applyDecoratedDescriptor(_class2.prototype, "enemySpeed", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 140;
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

(function(r) {
  r('virtual:///prerequisite-imports/main', 'chunks:///_virtual/main'); 
})(function(mid, cid) {
    System.register(mid, [cid], function (_export, _context) {
    return {
        setters: [function(_m) {
            var _exportObj = {};

            for (var _key in _m) {
              if (_key !== "default" && _key !== "__esModule") _exportObj[_key] = _m[_key];
            }
      
            _export(_exportObj);
        }],
        execute: function () { }
    };
    });
});